# TV Launcher

A small, fast Android TV launcher (Kotlin, plain Views). Built for low-end TVs.

## Features
- Rows like Google TV: **Favorites**, **Recent**, **All apps**
- D-pad friendly: focus highlight, focus restored after returning from an app
- Long-press OK on an app: Add/Remove favorite, Move, Assign shortcut key, Hide, App info, Uninstall
- **Move mode:** arrow keys move the app, OK finishes (works in Favorites and All apps)
- **Shortcut keys:** assign 0-9 or Red/Green/Yellow/Blue so that key opens the app on the home screen
  (only works while the launcher is on screen)
- **Wallpaper:** built-in gradients, or your own picture (see below)
- "Recent" lists apps you opened from this launcher
- Hidden apps can be brought back with the "Unhide all" button
- Fast: app images load in the background and are cached; the list is only re-read from
  the system when an app is installed, updated or removed

## Custom wallpaper
Copy a picture to the TV, named `wallpaper.jpg` (or `wallpaper.png`):
```
adb push wallpaper.jpg /sdcard/Android/data/com.example.tvlauncher/files/wallpaper.jpg
```
Then open **Wallpaper** at the top of the launcher and choose **Custom image**.

## Build
Push to GitHub. The workflow in `.github/workflows/build.yml` builds the APK.
Download `tv-launcher-apk` from the run's Artifacts.

## Install over ADB
```
adb connect <tv-ip>:5555
adb install -r tv-launcher.apk
```

Make it the home app (optional, may not work on every TV):
```
adb shell cmd package set-home-activity com.example.tvlauncher/.MainActivity
```

## Undo / safety net
```
adb uninstall com.example.tvlauncher
```
