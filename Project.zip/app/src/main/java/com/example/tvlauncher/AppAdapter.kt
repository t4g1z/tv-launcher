package com.example.tvlauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ImageView.ScaleType
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val spanCount: Int,
    private val loader: ImageLoader,
    private val onClick: (AppEntry) -> Unit,
    private val onLongClick: (AppEntry, Section) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var rows: List<Row> = emptyList()

    /** Key of the card that last had focus, so focus can be restored after a refresh. */
    var lastFocusedKey: String? = null

    /** Key of the card being moved in reorder mode (drawn with a yellow border). */
    var movingKey: String? = null
        private set

    fun submit(newRows: List<Row>) {
        rows = newRows
        notifyDataSetChanged()
    }

    fun setMoving(key: String?) {
        movingKey = key
        notifyDataSetChanged()
    }

    fun isHeader(position: Int): Boolean = rows.getOrNull(position) is Row.Header

    fun positionOfKey(key: String?): Int {
        if (key == null) return -1
        return rows.indexOfFirst { it is Row.Card && it.key == key }
    }

    fun firstCardPosition(): Int = rows.indexOfFirst { it is Row.Card }

    override fun getItemCount() = rows.size

    override fun getItemViewType(position: Int): Int =
        if (rows[position] is Row.Header) TYPE_HEADER else TYPE_CARD

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        if (viewType == TYPE_HEADER) {
            return HeaderVH(inflater.inflate(R.layout.item_header, parent, false))
        }
        val view = inflater.inflate(R.layout.item_app, parent, false)
        val density = parent.resources.displayMetrics.density
        val margin = (8 * density).toInt() // matches layout_margin in item_app.xml
        val usable = parent.width - parent.paddingLeft - parent.paddingRight
        if (usable > 0) {
            val cellWidth = usable / spanCount
            // 16:9 cards so TV banners fit exactly
            view.layoutParams.height = (cellWidth - 2 * margin) * 9 / 16
        }
        return CardVH(view)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val row = rows[position]) {
            is Row.Header -> (holder as HeaderVH).title.text = row.title
            is Row.Card -> bindCard(holder as CardVH, row)
        }
    }

    private fun bindCard(holder: CardVH, row: Row.Card) {
        val entry = row.entry
        val view = holder.itemView
        val density = view.resources.displayMetrics.density

        holder.boundPkg = entry.packageName
        holder.label.text = entry.label

        val cached = loader.cached(entry.packageName)
        if (cached != null) {
            showImage(holder, cached, density)
        } else {
            holder.icon.setImageDrawable(null)
            setIconMode(holder, density)
            loader.load(entry) { image ->
                if (holder.boundPkg == entry.packageName) showImage(holder, image, density)
            }
        }

        if (entry.shortcut != null) {
            holder.badge.text = entry.shortcut
            holder.badge.visibility = View.VISIBLE
        } else {
            holder.badge.visibility = View.GONE
        }

        view.isActivated = row.key == movingKey

        // Reset in case this holder was recycled while focused
        view.scaleX = 1f
        view.scaleY = 1f
        view.translationZ = 0f

        view.setOnClickListener { onClick(entry) }
        view.setOnLongClickListener {
            onLongClick(entry, row.section)
            true
        }
        view.setOnFocusChangeListener { v, hasFocus ->
            val scale = if (hasFocus) 1.1f else 1f
            v.animate().scaleX(scale).scaleY(scale).setDuration(100).start()
            // Higher Z so the enlarged card draws on top of its neighbours
            v.translationZ = if (hasFocus) 10f else 0f
            if (hasFocus) lastFocusedKey = row.key
        }
    }

    private fun showImage(holder: CardVH, image: CardImage, density: Float) {
        holder.icon.setImageBitmap(image.bitmap)
        if (image.isBanner) {
            holder.icon.scaleType = ScaleType.CENTER_CROP
            holder.icon.setPadding(0, 0, 0, 0)
            holder.label.visibility = View.GONE
        } else {
            setIconMode(holder, density)
        }
    }

    private fun setIconMode(holder: CardVH, density: Float) {
        val pad = (28 * density).toInt()
        holder.icon.scaleType = ScaleType.FIT_CENTER
        holder.icon.setPadding(pad, pad, pad, pad)
        holder.label.visibility = View.VISIBLE
    }

    class CardVH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
        val badge: TextView = view.findViewById(R.id.badge)
        var boundPkg: String? = null
    }

    class HeaderVH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.title)
    }

    companion object {
        private const val TYPE_HEADER = 0
        private const val TYPE_CARD = 1
    }
}
