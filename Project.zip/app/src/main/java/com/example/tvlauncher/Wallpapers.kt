package com.example.tvlauncher

import android.graphics.Color

object Wallpapers {
    class Preset(val name: String, val colors: IntArray)

    val presets = listOf(
        Preset("Midnight", intArrayOf(Color.parseColor("#0F1720"), Color.parseColor("#1B2A41"))),
        Preset("Ocean", intArrayOf(Color.parseColor("#0B3954"), Color.parseColor("#087E8B"))),
        Preset("Sunset", intArrayOf(Color.parseColor("#2B1B4A"), Color.parseColor("#B23A48"))),
        Preset("Forest", intArrayOf(Color.parseColor("#0B2B26"), Color.parseColor("#235347"))),
        Preset("Graphite", intArrayOf(Color.parseColor("#121212"), Color.parseColor("#2E2E2E"))),
        Preset("Plain dark", intArrayOf(Color.parseColor("#0F1720"), Color.parseColor("#0F1720")))
    )
}
