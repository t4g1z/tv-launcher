package com.example.tvlauncher

import android.content.pm.ActivityInfo

/** One launchable app. Images are loaded separately (see ImageLoader). */
class AppEntry(
    val packageName: String,
    val label: String,
    val info: ActivityInfo
) {
    /** Text like "1" or "Red, 3" when shortcut keys are assigned, else null */
    var shortcut: String? = null
}

enum class Section { FAVORITES, RECENT, ALL }

/** Things shown in the grid: section titles and app cards. */
sealed class Row {
    class Header(val title: String) : Row()

    class Card(val entry: AppEntry, val section: Section) : Row() {
        val key: String get() = "${section.name}:${entry.packageName}"
    }
}
