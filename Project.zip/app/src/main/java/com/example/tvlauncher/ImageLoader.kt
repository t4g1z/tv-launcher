package com.example.tvlauncher

import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.concurrent.Executors

private const val BANNER_W = 320
private const val BANNER_H = 180
private const val ICON_SIZE = 144

private fun cacheBytes(): Int =
    (Runtime.getRuntime().maxMemory() / 10).toInt().coerceIn(4 * 1024 * 1024, 24 * 1024 * 1024)

class CardImage(val bitmap: Bitmap, val isBanner: Boolean)

/**
 * Loads app banners/icons off the main thread, shrinks them to card size and keeps
 * them in a small memory cache, so the launcher opens instantly and scrolling stays smooth.
 * All public methods must be called from the main thread.
 */
class ImageLoader(private val pm: PackageManager) {

    private val cache = object : LruCache<String, CardImage>(cacheBytes()) {
        override fun sizeOf(key: String, value: CardImage): Int = value.bitmap.byteCount
    }
    private val pending = HashMap<String, MutableList<(CardImage) -> Unit>>()
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newFixedThreadPool(2)

    fun cached(pkg: String): CardImage? = cache.get(pkg)

    fun invalidate(pkg: String) {
        cache.remove(pkg)
    }

    fun load(entry: AppEntry, callback: (CardImage) -> Unit) {
        val pkg = entry.packageName
        val waiting = pending[pkg]
        if (waiting != null) {
            waiting.add(callback)
            return
        }
        pending[pkg] = mutableListOf(callback)
        val info = entry.info
        executor.execute {
            val image = runCatching { draw(info) }.getOrNull()
            main.post {
                val callbacks = pending.remove(pkg)
                if (image != null) {
                    cache.put(pkg, image)
                    callbacks?.forEach { it(image) }
                }
            }
        }
    }

    private fun draw(info: ActivityInfo): CardImage {
        val banner = runCatching { info.loadBanner(pm) }.getOrNull()
            ?: runCatching { info.applicationInfo.loadBanner(pm) }.getOrNull()
        val isBanner = banner != null
        val drawable = banner ?: runCatching { info.loadIcon(pm) }.getOrNull()

        val w = if (isBanner) BANNER_W else ICON_SIZE
        val h = if (isBanner) BANNER_H else ICON_SIZE
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        if (drawable != null) {
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, w, h)
            drawable.draw(canvas)
        }
        return CardImage(bitmap, isBanner)
    }
}
