package com.example.tvlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.concurrent.ConcurrentHashMap

class MainActivity : AppCompatActivity() {

    private class MoveState(val section: Section, val pkg: String)

    private lateinit var grid: RecyclerView
    private lateinit var adapter: AppAdapter
    private lateinit var imageLoader: ImageLoader
    private lateinit var unhideButton: View
    private lateinit var wallpaperView: ImageView
    private lateinit var hint: TextView

    /** Every launchable app (alphabetical). Only re-read from the system when something changed. */
    private var installed: List<AppEntry> = emptyList()

    /** Visible apps in the user's order. */
    private var allApps: List<AppEntry> = emptyList()

    private var installedDirty = true
    private var started = false
    private var loadToken = 0
    private var moving: MoveState? = null

    private val labelCache = ConcurrentHashMap<String, String>()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val pkg = intent?.data?.schemeSpecificPart
            if (pkg != null) {
                labelCache.remove(pkg)
                imageLoader.invalidate(pkg)
            }
            installedDirty = true
            if (started) loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wallpaperView = findViewById(R.id.wallpaper)
        hint = findViewById(R.id.hint)
        grid = findViewById(R.id.grid)
        unhideButton = findViewById(R.id.unhide)
        imageLoader = ImageLoader(packageManager)

        adapter = AppAdapter(
            SPAN_COUNT,
            imageLoader,
            { entry -> launchPackage(entry.packageName) },
            { entry, section -> showOptions(entry, section) }
        )

        val layoutManager = GridLayoutManager(this, SPAN_COUNT)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int =
                if (adapter.isHeader(position)) SPAN_COUNT else 1
        }
        grid.layoutManager = layoutManager
        grid.adapter = adapter
        grid.setHasFixedSize(true)
        grid.itemAnimator = null
        grid.setItemViewCacheSize(20)

        findViewById<View>(R.id.settings).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e: Exception) {
                toast(getString(R.string.cant_open))
            }
        }
        findViewById<View>(R.id.wallpaper_button).setOnClickListener { showWallpaperMenu() }
        unhideButton.setOnClickListener {
            prefs.edit().remove(KEY_HIDDEN).apply()
            render()
        }

        // A launcher should not close itself on Back
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // do nothing
            }
        })

        // Creates the folder where a custom wallpaper.jpg can be dropped
        try {
            getExternalFilesDir(null)
        } catch (e: Exception) {
            // ignore
        }

        applyWallpaper()

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
    }

    override fun onStart() {
        super.onStart()
        started = true
        // Only ask the system for the app list when something changed; otherwise just redraw
        if (installedDirty || installed.isEmpty()) loadApps() else render()
    }

    override fun onStop() {
        super.onStop()
        started = false
        endMove()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(packageReceiver)
        } catch (e: IllegalArgumentException) {
            // already unregistered
        }
    }

    // Pressing Home while we are already the foreground launcher
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            endMove()
            val pos = adapter.firstCardPosition()
            if (pos >= 0) {
                grid.scrollToPosition(0)
                focusPosition(pos)
            }
        }
    }

    // While moving an app, the arrow keys move it instead of the focus.
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (moving != null) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> moveStep(-1)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> moveStep(1)
                    KeyEvent.KEYCODE_DPAD_UP -> moveStep(-SPAN_COUNT)
                    KeyEvent.KEYCODE_DPAD_DOWN -> moveStep(SPAN_COUNT)
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER,
                    KeyEvent.KEYCODE_BACK -> endMove()
                }
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    // Shortcut keys. This only runs while the launcher is on screen (and no dialog is open),
    // so the keys behave normally inside every other app.
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val code = KeyMap.normalize(keyCode)
        if (code != null) {
            val pkg = prefs.getString(KeyMap.prefKey(code), null)
            if (pkg != null) {
                if (event.repeatCount == 0) launchPackage(pkg)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------------------------------------------------------------- stored lists

    private fun hiddenSet(): MutableSet<String> {
        val saved: Set<String>? = prefs.getStringSet(KEY_HIDDEN, null)
        return saved?.toMutableSet() ?: mutableSetOf()
    }

    private fun readList(key: String): MutableList<String> {
        val text = prefs.getString(key, "") ?: ""
        return text.split(",").filter { it.isNotEmpty() }.toMutableList()
    }

    private fun writeList(key: String, list: List<String>) {
        prefs.edit().putString(key, list.joinToString(",")).apply()
    }

    /** package name -> text such as "1" or "Red, 3" */
    private fun shortcutsByPackage(): Map<String, String> {
        val codesByPackage = HashMap<String, MutableList<Int>>()
        for ((name, value) in prefs.all) {
            val code = KeyMap.keyCodeFromPref(name) ?: continue
            val pkg = value as? String ?: continue
            codesByPackage.getOrPut(pkg) { mutableListOf() }.add(code)
        }
        return codesByPackage.mapValues { (_, codes) ->
            codes.sorted().joinToString(", ") { KeyMap.label(it) }
        }
    }

    private fun applyOrder(list: List<AppEntry>): List<AppEntry> {
        val index = HashMap<String, Int>()
        readList(KEY_ORDER).forEachIndexed { i, pkg -> index[pkg] = i }
        return list.sortedWith(
            compareBy<AppEntry> { index[it.packageName] ?: Int.MAX_VALUE }
                .thenBy { it.label.lowercase() }
        )
    }

    // ---------------------------------------------------------------- loading and drawing

    private fun loadApps() {
        val token = ++loadToken
        Thread {
            val pm = packageManager
            val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            val stdIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            // TV entries first, then ordinary launcher apps that have no TV entry
            val infos = pm.queryIntentActivities(tvIntent, 0) + pm.queryIntentActivities(stdIntent, 0)

            val seen = HashSet<String>()
            val result = ArrayList<AppEntry>()
            for (ri in infos) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val label = labelCache.getOrPut(pkg) {
                    runCatching { ri.loadLabel(pm).toString() }.getOrDefault(pkg)
                }
                result.add(AppEntry(pkg, label, ri.activityInfo))
            }
            result.sortBy { it.label.lowercase() }

            runOnUiThread {
                if (!isDestroyed && token == loadToken) {
                    installed = result
                    installedDirty = false
                    render()
                }
            }
        }.start()
    }

    /** Rebuilds Favorites / Recent / All apps from what is already in memory. Cheap. */
    private fun render() {
        val hidden = hiddenSet()
        val shortcuts = shortcutsByPackage()

        val visible = installed.filter { it.packageName !in hidden }
        for (entry in visible) entry.shortcut = shortcuts[entry.packageName]
        val ordered = applyOrder(visible)
        allApps = ordered
        val byPkg = ordered.associateBy { it.packageName }

        val rows = ArrayList<Row>()

        val favorites = readList(KEY_FAVS).mapNotNull { byPkg[it] }
        if (favorites.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.favorites)))
            favorites.forEach { rows.add(Row.Card(it, Section.FAVORITES)) }
        }

        val recent = readList(KEY_RECENTS).mapNotNull { byPkg[it] }.take(SPAN_COUNT)
        if (recent.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.recent)))
            recent.forEach { rows.add(Row.Card(it, Section.RECENT)) }
        }

        if (ordered.isNotEmpty()) {
            rows.add(Row.Header(getString(R.string.all_apps)))
            ordered.forEach { rows.add(Row.Card(it, Section.ALL)) }
        }

        // Only move focus if the user isn't busy in the top bar
        val keepFocus = currentFocus == null || grid.hasFocus()
        adapter.submit(rows)

        val hiddenCount = installed.count { it.packageName in hidden }
        unhideButton.visibility = if (hiddenCount > 0) View.VISIBLE else View.GONE

        if (keepFocus && adapter.firstCardPosition() >= 0) focusKey(adapter.lastFocusedKey)
    }

    private fun focusKey(key: String?) {
        var pos = adapter.positionOfKey(key)
        if (pos < 0) pos = adapter.firstCardPosition()
        if (pos >= 0) focusPosition(pos)
    }

    private fun focusPosition(position: Int) {
        grid.scrollToPosition(position)
        grid.postDelayed({
            val target = grid.findViewHolderForAdapterPosition(position)?.itemView
            if (target != null) target.requestFocus() else grid.requestFocus()
        }, 80)
    }

    // ---------------------------------------------------------------- launching

    private fun launchPackage(pkg: String) {
        val pm = packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
            ?: pm.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast(getString(R.string.cant_open))
            return
        }
        try {
            startActivity(intent)
            pushRecent(pkg)
        } catch (e: Exception) {
            toast(getString(R.string.cant_open))
        }
    }

    private fun pushRecent(pkg: String) {
        val list = readList(KEY_RECENTS)
        list.remove(pkg)
        list.add(0, pkg)
        writeList(KEY_RECENTS, list.take(12))
    }

    // ---------------------------------------------------------------- long-press menu

    private fun showOptions(entry: AppEntry, section: Section) {
        val isFavorite = entry.packageName in readList(KEY_FAVS)
        val actions = ArrayList<Pair<String, () -> Unit>>()

        actions.add(
            getString(if (isFavorite) R.string.remove_fav else R.string.add_fav) to { toggleFavorite(entry) }
        )
        if (section != Section.RECENT) {
            actions.add(getString(R.string.move_app) to { startMove(entry, section) })
        }
        actions.add(getString(R.string.assign_key) to { assignKey(entry) })
        if (entry.shortcut != null) {
            actions.add(getString(R.string.remove_keys) to { removeShortcuts(entry) })
        }
        actions.add(getString(R.string.hide) to { hideApp(entry) })
        actions.add(getString(R.string.app_info) to { openAppInfo(entry) })
        actions.add(getString(R.string.uninstall) to { uninstallApp(entry) })

        val labels = actions.map { it.first }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(entry.label)
            .setItems(labels) { _, which -> actions[which].second() }
            .show()
    }

    private fun toggleFavorite(entry: AppEntry) {
        val favs = readList(KEY_FAVS)
        if (!favs.remove(entry.packageName)) favs.add(entry.packageName)
        writeList(KEY_FAVS, favs)
        render()
    }

    private fun hideApp(entry: AppEntry) {
        val set = hiddenSet()
        set.add(entry.packageName)
        prefs.edit().putStringSet(KEY_HIDDEN, set).apply()
        render()
    }

    private fun openAppInfo(entry: AppEntry) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${entry.packageName}"))
            )
        } catch (e: Exception) {
            toast(getString(R.string.cant_open))
        }
    }

    private fun uninstallApp(entry: AppEntry) {
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${entry.packageName}")))
        } catch (e: Exception) {
            toast(getString(R.string.cant_open))
        }
    }

    // ---------------------------------------------------------------- shortcut keys

    private fun assignKey(entry: AppEntry) {
        AlertDialog.Builder(this)
            .setTitle(entry.label)
            .setMessage(getString(R.string.press_key_msg, entry.label))
            .setOnKeyListener { dialog, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                // Anything that isn't 0-9 or a color key (including Back) is handled normally
                val code = KeyMap.normalize(keyCode) ?: return@setOnKeyListener false
                prefs.edit().putString(KeyMap.prefKey(code), entry.packageName).apply()
                dialog.dismiss()
                toast(getString(R.string.key_assigned, KeyMap.label(code), entry.label))
                render()
                true
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun removeShortcuts(entry: AppEntry) {
        val editor = prefs.edit()
        for ((name, value) in prefs.all) {
            if (KeyMap.keyCodeFromPref(name) != null && value == entry.packageName) {
                editor.remove(name)
            }
        }
        editor.apply()
        render()
    }

    // ---------------------------------------------------------------- reorder mode

    private fun startMove(entry: AppEntry, section: Section) {
        moving = MoveState(section, entry.packageName)
        adapter.setMoving("${section.name}:${entry.packageName}")
        hint.text = getString(R.string.move_hint, entry.label)
        hint.visibility = View.VISIBLE
    }

    private fun endMove() {
        if (moving == null) return
        moving = null
        adapter.setMoving(null)
        hint.visibility = View.GONE
    }

    private fun moveStep(delta: Int) {
        val m = moving ?: return
        val visiblePkgs = allApps.map { it.packageName }
        val moved: Boolean = when (m.section) {
            Section.ALL -> {
                val ids = visiblePkgs.toMutableList()
                if (relocate(ids, m.pkg, delta)) {
                    writeList(KEY_ORDER, ids + readList(KEY_ORDER).filter { it !in ids })
                    true
                } else {
                    false
                }
            }
            Section.FAVORITES -> {
                val full = readList(KEY_FAVS)
                val shown = full.filter { it in visiblePkgs }.toMutableList()
                if (relocate(shown, m.pkg, delta)) {
                    writeList(KEY_FAVS, shown + full.filter { it !in visiblePkgs })
                    true
                } else {
                    false
                }
            }
            Section.RECENT -> false
        }
        if (moved) {
            adapter.lastFocusedKey = "${m.section.name}:${m.pkg}"
            render()
        }
    }

    private fun relocate(list: MutableList<String>, pkg: String, delta: Int): Boolean {
        val from = list.indexOf(pkg)
        if (from < 0) return false
        val to = (from + delta).coerceIn(0, list.size - 1)
        if (to == from) return false
        list.removeAt(from)
        list.add(to, pkg)
        return true
    }

    // ---------------------------------------------------------------- wallpaper

    private fun customWallpaperFile(): File? {
        val dir: File = (try {
            getExternalFilesDir(null)
        } catch (e: Exception) {
            null
        }) ?: return null
        return listOf("wallpaper.jpg", "wallpaper.jpeg", "wallpaper.png")
            .map { File(dir, it) }
            .firstOrNull { it.exists() }
    }

    private fun applyWallpaper() {
        val choice = prefs.getString(KEY_WALLPAPER, "preset:0") ?: "preset:0"
        if (choice == "custom") {
            val file = customWallpaperFile()
            if (file != null) {
                loadCustomWallpaper(file)
                return
            }
        }
        val index = (choice.removePrefix("preset:").toIntOrNull() ?: 0)
            .coerceIn(0, Wallpapers.presets.size - 1)
        wallpaperView.clearColorFilter()
        wallpaperView.setImageDrawable(
            GradientDrawable(GradientDrawable.Orientation.TL_BR, Wallpapers.presets[index].colors)
        )
    }

    private fun loadCustomWallpaper(file: File) {
        Thread {
            val bitmap: Bitmap? = runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.path, bounds)
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= 1920) sample *= 2
                val options = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                BitmapFactory.decodeFile(file.path, options)
            }.getOrNull()

            runOnUiThread {
                if (bitmap != null && !isDestroyed) {
                    // Darken a little so the cards stay readable on bright pictures
                    wallpaperView.setColorFilter(Color.argb(110, 0, 0, 0))
                    wallpaperView.setImageBitmap(bitmap)
                }
            }
        }.start()
    }

    private fun showWallpaperMenu() {
        val names = Wallpapers.presets.map { it.name } + getString(R.string.custom_image)
        AlertDialog.Builder(this)
            .setTitle(R.string.wallpaper)
            .setItems(names.toTypedArray()) { _, which ->
                if (which < Wallpapers.presets.size) {
                    prefs.edit().putString(KEY_WALLPAPER, "preset:$which").apply()
                    applyWallpaper()
                } else if (customWallpaperFile() != null) {
                    prefs.edit().putString(KEY_WALLPAPER, "custom").apply()
                    applyWallpaper()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle(R.string.custom_image)
                        .setMessage(R.string.custom_help)
                        .setPositiveButton(android.R.string.ok, null)
                        .show()
                }
            }
            .show()
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val SPAN_COUNT = 5
        private const val KEY_HIDDEN = "hidden"
        private const val KEY_ORDER = "order"
        private const val KEY_FAVS = "favs"
        private const val KEY_RECENTS = "recents"
        private const val KEY_WALLPAPER = "wallpaper"
    }
}
