package com.example.tvlauncher

import android.graphics.drawable.Drawable

class AppEntry(
    val packageName: String,
    val label: String,
    val image: Drawable?,
    val isBanner: Boolean,
    /** Text like "1" or "Red, 3" when shortcut keys are assigned, else null */
    val shortcut: String?
)
