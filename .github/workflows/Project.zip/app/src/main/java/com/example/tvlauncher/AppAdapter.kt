package com.example.tvlauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ImageView.ScaleType
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val spanCount: Int,
    private val onClick: (AppEntry) -> Unit,
    private val onLongClick: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppEntry> = emptyList()

    /** Position of the last item that had focus, so we can restore it later. */
    var lastFocused = 0
        private set

    fun submit(newItems: List<AppEntry>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        val density = parent.resources.displayMetrics.density
        val margin = (8 * density).toInt() // matches layout_margin in item_app.xml
        val usable = parent.width - parent.paddingLeft - parent.paddingRight
        if (usable > 0) {
            val cellWidth = usable / spanCount
            // 16:9 cards so TV banners fit exactly
            view.layoutParams.height = (cellWidth - 2 * margin) * 9 / 16
        }
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = items[position]
        val density = holder.itemView.resources.displayMetrics.density

        holder.icon.setImageDrawable(entry.image)
        if (entry.isBanner) {
            holder.icon.scaleType = ScaleType.CENTER_CROP
            holder.icon.setPadding(0, 0, 0, 0)
            holder.label.visibility = View.GONE
        } else {
            val pad = (28 * density).toInt()
            holder.icon.scaleType = ScaleType.FIT_CENTER
            holder.icon.setPadding(pad, pad, pad, pad)
            holder.label.text = entry.label
            holder.label.visibility = View.VISIBLE
        }

        if (entry.shortcut != null) {
            holder.badge.text = entry.shortcut
            holder.badge.visibility = View.VISIBLE
        } else {
            holder.badge.visibility = View.GONE
        }

        // Reset in case this holder was recycled while focused
        holder.itemView.scaleX = 1f
        holder.itemView.scaleY = 1f
        holder.itemView.translationZ = 0f

        holder.itemView.setOnClickListener { onClick(entry) }
        holder.itemView.setOnLongClickListener {
            onLongClick(entry)
            true
        }
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            val scale = if (hasFocus) 1.1f else 1f
            v.animate().scaleX(scale).scaleY(scale).setDuration(120).start()
            // Higher Z so the enlarged card draws on top of its neighbours
            v.translationZ = if (hasFocus) 10f else 0f
            if (hasFocus) {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) lastFocused = pos
            }
        }
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
        val badge: TextView = view.findViewById(R.id.badge)
    }
}
