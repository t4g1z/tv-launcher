package com.example.tvlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var grid: RecyclerView
    private lateinit var adapter: AppAdapter
    private lateinit var unhideButton: View

    private var loadToken = 0

    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        grid = findViewById(R.id.grid)
        unhideButton = findViewById(R.id.unhide)

        adapter = AppAdapter(SPAN_COUNT, { launchPackage(it.packageName) }, ::showOptions)
        grid.layoutManager = GridLayoutManager(this, SPAN_COUNT)
        grid.adapter = adapter
        grid.setHasFixedSize(true)
        grid.itemAnimator = null
        grid.setItemViewCacheSize(20)

        findViewById<View>(R.id.settings).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (e: Exception) {
                toast(getString(R.string.cant_open))
            }
        }

        unhideButton.setOnClickListener {
            prefs.edit().remove(KEY_HIDDEN).apply()
            loadApps()
        }

        // A launcher should not close itself on Back
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // do nothing
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
        loadApps()
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(packageReceiver)
        } catch (e: IllegalArgumentException) {
            // already unregistered
        }
    }

    // Pressing Home while we are already the foreground launcher
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME) && adapter.itemCount > 0) {
            focusItem(0)
        }
    }

    // Shortcut keys. This only runs while the launcher is on screen (and no dialog is open),
    // so the keys behave normally inside every other app.
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val code = KeyMap.normalize(keyCode)
        if (code != null) {
            val pkg = prefs.getString(KeyMap.prefKey(code), null)
            if (pkg != null) {
                if (event.repeatCount == 0) launchPackage(pkg)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun hiddenSet(): MutableSet<String> {
        val saved: Set<String>? = prefs.getStringSet(KEY_HIDDEN, null)
        return saved?.toMutableSet() ?: mutableSetOf()
    }

    /** package name -> text such as "1" or "Red, 3" */
    private fun shortcutsByPackage(): Map<String, String> {
        val codesByPackage = HashMap<String, MutableList<Int>>()
        for ((name, value) in prefs.all) {
            val code = KeyMap.keyCodeFromPref(name) ?: continue
            val pkg = value as? String ?: continue
            codesByPackage.getOrPut(pkg) { mutableListOf() }.add(code)
        }
        return codesByPackage.mapValues { (_, codes) ->
            codes.sorted().joinToString(", ") { KeyMap.label(it) }
        }
    }

    private fun loadApps() {
        val token = ++loadToken
        val hidden = hiddenSet()
        val shortcuts = shortcutsByPackage()

        Thread {
            val pm = packageManager
            val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            val stdIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            // TV entries first, then ordinary launcher apps that have no TV entry
            val infos = pm.queryIntentActivities(tvIntent, 0) + pm.queryIntentActivities(stdIntent, 0)

            val seen = HashSet<String>()
            val result = ArrayList<AppEntry>()
            for (ri in infos) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || pkg in hidden || !seen.add(pkg)) continue
                val banner = runCatching { ri.activityInfo.loadBanner(pm) }.getOrNull()
                val image = banner ?: runCatching { ri.loadIcon(pm) }.getOrNull()
                val label = runCatching { ri.loadLabel(pm).toString() }.getOrDefault(pkg)
                result.add(AppEntry(pkg, label, image, banner != null, shortcuts[pkg]))
            }
            result.sortBy { it.label.lowercase() }

            runOnUiThread {
                if (!isDestroyed && token == loadToken) applyList(result, hidden.size)
            }
        }.start()
    }

    private fun applyList(list: List<AppEntry>, hiddenCount: Int) {
        // Only move focus if the user isn't busy in the top bar
        val restoreFocus = currentFocus == null || grid.hasFocus()
        adapter.submit(list)
        unhideButton.visibility = if (hiddenCount > 0) View.VISIBLE else View.GONE
        if (restoreFocus && list.isNotEmpty()) {
            focusItem(adapter.lastFocused.coerceIn(0, list.size - 1))
        }
    }

    private fun focusItem(position: Int) {
        grid.scrollToPosition(position)
        grid.postDelayed({
            val target = grid.findViewHolderForAdapterPosition(position)?.itemView
            if (target != null) target.requestFocus() else grid.requestFocus()
        }, 80)
    }

    private fun launchPackage(pkg: String) {
        val pm = packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(pkg)
            ?: pm.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            toast(getString(R.string.cant_open))
            return
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast(getString(R.string.cant_open))
        }
    }

    private fun showOptions(entry: AppEntry) {
        val options = mutableListOf(
            getString(R.string.hide),
            getString(R.string.app_info),
            getString(R.string.uninstall),
            getString(R.string.assign_key)
        )
        if (entry.shortcut != null) options.add(getString(R.string.remove_keys))

        AlertDialog.Builder(this)
            .setTitle(entry.label)
            .setItems(options.toTypedArray()) { _, which ->
                when (which) {
                    0 -> hideApp(entry)
                    1 -> openAppInfo(entry)
                    2 -> uninstallApp(entry)
                    3 -> assignKey(entry)
                    4 -> removeShortcuts(entry)
                }
            }
            .show()
    }

    private fun assignKey(entry: AppEntry) {
        AlertDialog.Builder(this)
            .setTitle(entry.label)
            .setMessage(getString(R.string.press_key_msg, entry.label))
            .setOnKeyListener { dialog, keyCode, event ->
                if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                // Anything that isn't 0-9 or a color key (including Back) is handled normally
                val code = KeyMap.normalize(keyCode) ?: return@setOnKeyListener false
                prefs.edit().putString(KeyMap.prefKey(code), entry.packageName).apply()
                dialog.dismiss()
                toast(getString(R.string.key_assigned, KeyMap.label(code), entry.label))
                loadApps()
                true
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun removeShortcuts(entry: AppEntry) {
        val editor = prefs.edit()
        for ((name, value) in prefs.all) {
            if (KeyMap.keyCodeFromPref(name) != null && value == entry.packageName) {
                editor.remove(name)
            }
        }
        editor.apply()
        loadApps()
    }

    private fun hideApp(entry: AppEntry) {
        val set = hiddenSet()
        set.add(entry.packageName)
        prefs.edit().putStringSet(KEY_HIDDEN, set).apply()
        loadApps()
    }

    private fun openAppInfo(entry: AppEntry) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${entry.packageName}"))
            )
        } catch (e: Exception) {
            toast(getString(R.string.cant_open))
        }
    }

    private fun uninstallApp(entry: AppEntry) {
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${entry.packageName}")))
        } catch (e: Exception) {
            toast(getString(R.string.cant_open))
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    companion object {
        private const val SPAN_COUNT = 5
        private const val KEY_HIDDEN = "hidden"
    }
}
