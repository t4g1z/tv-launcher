package com.example.tvlauncher

import android.view.KeyEvent

/** Which remote keys can be used as app shortcuts, and how they are stored. */
object KeyMap {
    private const val PREFIX = "key_"

    /** Returns a canonical key code if this key may be used as a shortcut, otherwise null. */
    fun normalize(keyCode: Int): Int? = when (keyCode) {
        in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> keyCode
        in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 ->
            keyCode - KeyEvent.KEYCODE_NUMPAD_0 + KeyEvent.KEYCODE_0
        KeyEvent.KEYCODE_PROG_RED,
        KeyEvent.KEYCODE_PROG_GREEN,
        KeyEvent.KEYCODE_PROG_YELLOW,
        KeyEvent.KEYCODE_PROG_BLUE -> keyCode
        else -> null
    }

    fun label(keyCode: Int): String = when (keyCode) {
        in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> (keyCode - KeyEvent.KEYCODE_0).toString()
        KeyEvent.KEYCODE_PROG_RED -> "Red"
        KeyEvent.KEYCODE_PROG_GREEN -> "Green"
        KeyEvent.KEYCODE_PROG_YELLOW -> "Yellow"
        KeyEvent.KEYCODE_PROG_BLUE -> "Blue"
        else -> KeyEvent.keyCodeToString(keyCode)
    }

    fun prefKey(keyCode: Int): String = PREFIX + keyCode

    fun keyCodeFromPref(name: String): Int? =
        if (name.startsWith(PREFIX)) name.removePrefix(PREFIX).toIntOrNull() else null
}
