# TV Launcher

A small, lightweight Android TV launcher (Kotlin, plain Views). Built for low-end TVs.

## Features
- App grid (TV apps first, plus normal apps that have no TV entry)
- D-pad friendly: focus highlight, focus restored after returning from an app
- Long-press OK on an app: Hide / App info / Uninstall
- "Unhide all" button appears when apps are hidden
- Shortcut keys: long-press an app > "Assign shortcut key", then press 0-9 or a
  Red/Green/Yellow/Blue button on the remote. On the home screen that key opens the app.
  (Only works while the launcher is on screen.)
- Clock and Settings shortcut
- List refreshes automatically when apps are installed or removed

## Build
Push to GitHub. The workflow in `.github/workflows/build.yml` builds the APK.
Download `tv-launcher-apk` from the run's Artifacts.

## Install over ADB
```
adb connect <tv-ip>:5555
adb install -r app-debug.apk
```

Make it the home app (optional, may not work on every TV):
```
adb shell cmd package set-home-activity com.example.tvlauncher/.MainActivity
```

## Undo / safety net
```
adb uninstall com.example.tvlauncher
```
